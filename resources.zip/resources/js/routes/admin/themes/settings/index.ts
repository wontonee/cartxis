import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::update
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:103
 * @route '/admin/appearance/themes/{slug}/settings'
 */
export const update = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/appearance/themes/{slug}/settings',
} satisfies RouteDefinition<["put"]>

/**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::update
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:103
 * @route '/admin/appearance/themes/{slug}/settings'
 */
update.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return update.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::update
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:103
 * @route '/admin/appearance/themes/{slug}/settings'
 */
update.put = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::update
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:103
 * @route '/admin/appearance/themes/{slug}/settings'
 */
    const updateForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::update
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:103
 * @route '/admin/appearance/themes/{slug}/settings'
 */
        updateForm.put = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const settings = {
    update: Object.assign(update, update),
}

export default settings