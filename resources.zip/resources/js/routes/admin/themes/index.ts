import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
import settings69f00b from './settings'
/**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::index
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:24
 * @route '/admin/appearance/themes'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/appearance/themes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::index
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:24
 * @route '/admin/appearance/themes'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::index
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:24
 * @route '/admin/appearance/themes'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::index
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:24
 * @route '/admin/appearance/themes'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::index
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:24
 * @route '/admin/appearance/themes'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::index
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:24
 * @route '/admin/appearance/themes'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::index
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:24
 * @route '/admin/appearance/themes'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::activate
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:54
 * @route '/admin/appearance/themes/{slug}/activate'
 */
export const activate = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: activate.url(args, options),
    method: 'post',
})

activate.definition = {
    methods: ["post"],
    url: '/admin/appearance/themes/{slug}/activate',
} satisfies RouteDefinition<["post"]>

/**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::activate
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:54
 * @route '/admin/appearance/themes/{slug}/activate'
 */
activate.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return activate.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::activate
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:54
 * @route '/admin/appearance/themes/{slug}/activate'
 */
activate.post = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: activate.url(args, options),
    method: 'post',
})

    /**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::activate
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:54
 * @route '/admin/appearance/themes/{slug}/activate'
 */
    const activateForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: activate.url(args, options),
        method: 'post',
    })

            /**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::activate
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:54
 * @route '/admin/appearance/themes/{slug}/activate'
 */
        activateForm.post = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: activate.url(args, options),
            method: 'post',
        })
    
    activate.form = activateForm
/**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::settings
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:74
 * @route '/admin/appearance/themes/{slug}/settings'
 */
export const settings = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: settings.url(args, options),
    method: 'get',
})

settings.definition = {
    methods: ["get","head"],
    url: '/admin/appearance/themes/{slug}/settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::settings
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:74
 * @route '/admin/appearance/themes/{slug}/settings'
 */
settings.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return settings.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::settings
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:74
 * @route '/admin/appearance/themes/{slug}/settings'
 */
settings.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: settings.url(args, options),
    method: 'get',
})
/**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::settings
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:74
 * @route '/admin/appearance/themes/{slug}/settings'
 */
settings.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: settings.url(args, options),
    method: 'head',
})

    /**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::settings
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:74
 * @route '/admin/appearance/themes/{slug}/settings'
 */
    const settingsForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: settings.url(args, options),
        method: 'get',
    })

            /**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::settings
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:74
 * @route '/admin/appearance/themes/{slug}/settings'
 */
        settingsForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: settings.url(args, options),
            method: 'get',
        })
            /**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::settings
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:74
 * @route '/admin/appearance/themes/{slug}/settings'
 */
        settingsForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: settings.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    settings.form = settingsForm
/**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::destroy
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:131
 * @route '/admin/appearance/themes/{slug}'
 */
export const destroy = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/appearance/themes/{slug}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::destroy
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:131
 * @route '/admin/appearance/themes/{slug}'
 */
destroy.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return destroy.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::destroy
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:131
 * @route '/admin/appearance/themes/{slug}'
 */
destroy.delete = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::destroy
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:131
 * @route '/admin/appearance/themes/{slug}'
 */
    const destroyForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::destroy
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:131
 * @route '/admin/appearance/themes/{slug}'
 */
        destroyForm.delete = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::upload
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:156
 * @route '/admin/appearance/themes/upload'
 */
export const upload = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upload.url(options),
    method: 'post',
})

upload.definition = {
    methods: ["post"],
    url: '/admin/appearance/themes/upload',
} satisfies RouteDefinition<["post"]>

/**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::upload
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:156
 * @route '/admin/appearance/themes/upload'
 */
upload.url = (options?: RouteQueryOptions) => {
    return upload.definition.url + queryParams(options)
}

/**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::upload
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:156
 * @route '/admin/appearance/themes/upload'
 */
upload.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upload.url(options),
    method: 'post',
})

    /**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::upload
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:156
 * @route '/admin/appearance/themes/upload'
 */
    const uploadForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: upload.url(options),
        method: 'post',
    })

            /**
* @see \Packages\Core\Http\Controllers\Admin\ThemeController::upload
 * @see packages/Core/Http/Controllers/Admin/ThemeController.php:156
 * @route '/admin/appearance/themes/upload'
 */
        uploadForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: upload.url(options),
            method: 'post',
        })
    
    upload.form = uploadForm
const themes = {
    index: Object.assign(index, index),
activate: Object.assign(activate, activate),
settings: Object.assign(settings, settings69f00b),
destroy: Object.assign(destroy, destroy),
upload: Object.assign(upload, upload),
}

export default themes