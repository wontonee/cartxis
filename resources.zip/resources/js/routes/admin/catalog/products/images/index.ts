import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductImageController::upload
 * @see packages/Product/Http/Controllers/Admin/ProductImageController.php:17
 * @route '/admin/catalog/products/{product}/images/upload'
 */
export const upload = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upload.url(args, options),
    method: 'post',
})

upload.definition = {
    methods: ["post"],
    url: '/admin/catalog/products/{product}/images/upload',
} satisfies RouteDefinition<["post"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductImageController::upload
 * @see packages/Product/Http/Controllers/Admin/ProductImageController.php:17
 * @route '/admin/catalog/products/{product}/images/upload'
 */
upload.url = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { product: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    product: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        product: typeof args.product === 'object'
                ? args.product.id
                : args.product,
                }

    return upload.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductImageController::upload
 * @see packages/Product/Http/Controllers/Admin/ProductImageController.php:17
 * @route '/admin/catalog/products/{product}/images/upload'
 */
upload.post = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upload.url(args, options),
    method: 'post',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductImageController::upload
 * @see packages/Product/Http/Controllers/Admin/ProductImageController.php:17
 * @route '/admin/catalog/products/{product}/images/upload'
 */
    const uploadForm = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: upload.url(args, options),
        method: 'post',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductImageController::upload
 * @see packages/Product/Http/Controllers/Admin/ProductImageController.php:17
 * @route '/admin/catalog/products/{product}/images/upload'
 */
        uploadForm.post = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: upload.url(args, options),
            method: 'post',
        })
    
    upload.form = uploadForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductImageController::destroy
 * @see packages/Product/Http/Controllers/Admin/ProductImageController.php:68
 * @route '/admin/catalog/products/{product}/images/{image}'
 */
export const destroy = (args: { product: number | { id: number }, image: number | { id: number } } | [product: number | { id: number }, image: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/catalog/products/{product}/images/{image}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductImageController::destroy
 * @see packages/Product/Http/Controllers/Admin/ProductImageController.php:68
 * @route '/admin/catalog/products/{product}/images/{image}'
 */
destroy.url = (args: { product: number | { id: number }, image: number | { id: number } } | [product: number | { id: number }, image: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    product: args[0],
                    image: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        product: typeof args.product === 'object'
                ? args.product.id
                : args.product,
                                image: typeof args.image === 'object'
                ? args.image.id
                : args.image,
                }

    return destroy.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace('{image}', parsedArgs.image.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductImageController::destroy
 * @see packages/Product/Http/Controllers/Admin/ProductImageController.php:68
 * @route '/admin/catalog/products/{product}/images/{image}'
 */
destroy.delete = (args: { product: number | { id: number }, image: number | { id: number } } | [product: number | { id: number }, image: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductImageController::destroy
 * @see packages/Product/Http/Controllers/Admin/ProductImageController.php:68
 * @route '/admin/catalog/products/{product}/images/{image}'
 */
    const destroyForm = (args: { product: number | { id: number }, image: number | { id: number } } | [product: number | { id: number }, image: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductImageController::destroy
 * @see packages/Product/Http/Controllers/Admin/ProductImageController.php:68
 * @route '/admin/catalog/products/{product}/images/{image}'
 */
        destroyForm.delete = (args: { product: number | { id: number }, image: number | { id: number } } | [product: number | { id: number }, image: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductImageController::reorder
 * @see packages/Product/Http/Controllers/Admin/ProductImageController.php:99
 * @route '/admin/catalog/products/{product}/images/reorder'
 */
export const reorder = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorder.url(args, options),
    method: 'post',
})

reorder.definition = {
    methods: ["post"],
    url: '/admin/catalog/products/{product}/images/reorder',
} satisfies RouteDefinition<["post"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductImageController::reorder
 * @see packages/Product/Http/Controllers/Admin/ProductImageController.php:99
 * @route '/admin/catalog/products/{product}/images/reorder'
 */
reorder.url = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { product: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    product: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        product: typeof args.product === 'object'
                ? args.product.id
                : args.product,
                }

    return reorder.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductImageController::reorder
 * @see packages/Product/Http/Controllers/Admin/ProductImageController.php:99
 * @route '/admin/catalog/products/{product}/images/reorder'
 */
reorder.post = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorder.url(args, options),
    method: 'post',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductImageController::reorder
 * @see packages/Product/Http/Controllers/Admin/ProductImageController.php:99
 * @route '/admin/catalog/products/{product}/images/reorder'
 */
    const reorderForm = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reorder.url(args, options),
        method: 'post',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductImageController::reorder
 * @see packages/Product/Http/Controllers/Admin/ProductImageController.php:99
 * @route '/admin/catalog/products/{product}/images/reorder'
 */
        reorderForm.post = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reorder.url(args, options),
            method: 'post',
        })
    
    reorder.form = reorderForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductImageController::setMain
 * @see packages/Product/Http/Controllers/Admin/ProductImageController.php:123
 * @route '/admin/catalog/products/{product}/images/{image}/set-main'
 */
export const setMain = (args: { product: number | { id: number }, image: number | { id: number } } | [product: number | { id: number }, image: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: setMain.url(args, options),
    method: 'post',
})

setMain.definition = {
    methods: ["post"],
    url: '/admin/catalog/products/{product}/images/{image}/set-main',
} satisfies RouteDefinition<["post"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductImageController::setMain
 * @see packages/Product/Http/Controllers/Admin/ProductImageController.php:123
 * @route '/admin/catalog/products/{product}/images/{image}/set-main'
 */
setMain.url = (args: { product: number | { id: number }, image: number | { id: number } } | [product: number | { id: number }, image: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    product: args[0],
                    image: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        product: typeof args.product === 'object'
                ? args.product.id
                : args.product,
                                image: typeof args.image === 'object'
                ? args.image.id
                : args.image,
                }

    return setMain.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace('{image}', parsedArgs.image.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductImageController::setMain
 * @see packages/Product/Http/Controllers/Admin/ProductImageController.php:123
 * @route '/admin/catalog/products/{product}/images/{image}/set-main'
 */
setMain.post = (args: { product: number | { id: number }, image: number | { id: number } } | [product: number | { id: number }, image: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: setMain.url(args, options),
    method: 'post',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductImageController::setMain
 * @see packages/Product/Http/Controllers/Admin/ProductImageController.php:123
 * @route '/admin/catalog/products/{product}/images/{image}/set-main'
 */
    const setMainForm = (args: { product: number | { id: number }, image: number | { id: number } } | [product: number | { id: number }, image: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: setMain.url(args, options),
        method: 'post',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductImageController::setMain
 * @see packages/Product/Http/Controllers/Admin/ProductImageController.php:123
 * @route '/admin/catalog/products/{product}/images/{image}/set-main'
 */
        setMainForm.post = (args: { product: number | { id: number }, image: number | { id: number } } | [product: number | { id: number }, image: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: setMain.url(args, options),
            method: 'post',
        })
    
    setMain.form = setMainForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductImageController::update
 * @see packages/Product/Http/Controllers/Admin/ProductImageController.php:144
 * @route '/admin/catalog/products/{product}/images/{image}'
 */
export const update = (args: { product: number | { id: number }, image: number | { id: number } } | [product: number | { id: number }, image: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/catalog/products/{product}/images/{image}',
} satisfies RouteDefinition<["put"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductImageController::update
 * @see packages/Product/Http/Controllers/Admin/ProductImageController.php:144
 * @route '/admin/catalog/products/{product}/images/{image}'
 */
update.url = (args: { product: number | { id: number }, image: number | { id: number } } | [product: number | { id: number }, image: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    product: args[0],
                    image: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        product: typeof args.product === 'object'
                ? args.product.id
                : args.product,
                                image: typeof args.image === 'object'
                ? args.image.id
                : args.image,
                }

    return update.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace('{image}', parsedArgs.image.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductImageController::update
 * @see packages/Product/Http/Controllers/Admin/ProductImageController.php:144
 * @route '/admin/catalog/products/{product}/images/{image}'
 */
update.put = (args: { product: number | { id: number }, image: number | { id: number } } | [product: number | { id: number }, image: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductImageController::update
 * @see packages/Product/Http/Controllers/Admin/ProductImageController.php:144
 * @route '/admin/catalog/products/{product}/images/{image}'
 */
    const updateForm = (args: { product: number | { id: number }, image: number | { id: number } } | [product: number | { id: number }, image: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductImageController::update
 * @see packages/Product/Http/Controllers/Admin/ProductImageController.php:144
 * @route '/admin/catalog/products/{product}/images/{image}'
 */
        updateForm.put = (args: { product: number | { id: number }, image: number | { id: number } } | [product: number | { id: number }, image: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const images = {
    upload: Object.assign(upload, upload),
destroy: Object.assign(destroy, destroy),
reorder: Object.assign(reorder, reorder),
setMain: Object.assign(setMain, setMain),
update: Object.assign(update, update),
}

export default images