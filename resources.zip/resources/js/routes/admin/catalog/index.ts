import products from './products'
import categories from './categories'
import attributes from './attributes'
import brands from './brands'
import reviews from './reviews'
const catalog = {
    products: Object.assign(products, products),
categories: Object.assign(categories, categories),
attributes: Object.assign(attributes, attributes),
brands: Object.assign(brands, brands),
reviews: Object.assign(reviews, reviews),
}

export default catalog