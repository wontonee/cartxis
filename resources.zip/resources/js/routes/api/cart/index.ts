import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \Vortex\Cart\Http\Controllers\Api\CartController::index
 * @see packages/Cart/Http/Controllers/Api/CartController.php:16
 * @route '/api/cart'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/cart',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Vortex\Cart\Http\Controllers\Api\CartController::index
 * @see packages/Cart/Http/Controllers/Api/CartController.php:16
 * @route '/api/cart'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \Vortex\Cart\Http\Controllers\Api\CartController::index
 * @see packages/Cart/Http/Controllers/Api/CartController.php:16
 * @route '/api/cart'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \Vortex\Cart\Http\Controllers\Api\CartController::index
 * @see packages/Cart/Http/Controllers/Api/CartController.php:16
 * @route '/api/cart'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \Vortex\Cart\Http\Controllers\Api\CartController::index
 * @see packages/Cart/Http/Controllers/Api/CartController.php:16
 * @route '/api/cart'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \Vortex\Cart\Http\Controllers\Api\CartController::index
 * @see packages/Cart/Http/Controllers/Api/CartController.php:16
 * @route '/api/cart'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \Vortex\Cart\Http\Controllers\Api\CartController::index
 * @see packages/Cart/Http/Controllers/Api/CartController.php:16
 * @route '/api/cart'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \Vortex\Cart\Http\Controllers\Api\CartController::add
 * @see packages/Cart/Http/Controllers/Api/CartController.php:30
 * @route '/api/cart/add'
 */
export const add = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: add.url(options),
    method: 'post',
})

add.definition = {
    methods: ["post"],
    url: '/api/cart/add',
} satisfies RouteDefinition<["post"]>

/**
* @see \Vortex\Cart\Http\Controllers\Api\CartController::add
 * @see packages/Cart/Http/Controllers/Api/CartController.php:30
 * @route '/api/cart/add'
 */
add.url = (options?: RouteQueryOptions) => {
    return add.definition.url + queryParams(options)
}

/**
* @see \Vortex\Cart\Http\Controllers\Api\CartController::add
 * @see packages/Cart/Http/Controllers/Api/CartController.php:30
 * @route '/api/cart/add'
 */
add.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: add.url(options),
    method: 'post',
})

    /**
* @see \Vortex\Cart\Http\Controllers\Api\CartController::add
 * @see packages/Cart/Http/Controllers/Api/CartController.php:30
 * @route '/api/cart/add'
 */
    const addForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: add.url(options),
        method: 'post',
    })

            /**
* @see \Vortex\Cart\Http\Controllers\Api\CartController::add
 * @see packages/Cart/Http/Controllers/Api/CartController.php:30
 * @route '/api/cart/add'
 */
        addForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: add.url(options),
            method: 'post',
        })
    
    add.form = addForm
/**
* @see \Vortex\Cart\Http\Controllers\Api\CartController::update
 * @see packages/Cart/Http/Controllers/Api/CartController.php:89
 * @route '/api/cart/update/{itemId}'
 */
export const update = (args: { itemId: string | number } | [itemId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/cart/update/{itemId}',
} satisfies RouteDefinition<["put"]>

/**
* @see \Vortex\Cart\Http\Controllers\Api\CartController::update
 * @see packages/Cart/Http/Controllers/Api/CartController.php:89
 * @route '/api/cart/update/{itemId}'
 */
update.url = (args: { itemId: string | number } | [itemId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { itemId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    itemId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        itemId: args.itemId,
                }

    return update.definition.url
            .replace('{itemId}', parsedArgs.itemId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Vortex\Cart\Http\Controllers\Api\CartController::update
 * @see packages/Cart/Http/Controllers/Api/CartController.php:89
 * @route '/api/cart/update/{itemId}'
 */
update.put = (args: { itemId: string | number } | [itemId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \Vortex\Cart\Http\Controllers\Api\CartController::update
 * @see packages/Cart/Http/Controllers/Api/CartController.php:89
 * @route '/api/cart/update/{itemId}'
 */
    const updateForm = (args: { itemId: string | number } | [itemId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \Vortex\Cart\Http\Controllers\Api\CartController::update
 * @see packages/Cart/Http/Controllers/Api/CartController.php:89
 * @route '/api/cart/update/{itemId}'
 */
        updateForm.put = (args: { itemId: string | number } | [itemId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \Vortex\Cart\Http\Controllers\Api\CartController::remove
 * @see packages/Cart/Http/Controllers/Api/CartController.php:124
 * @route '/api/cart/remove/{itemId}'
 */
export const remove = (args: { itemId: string | number } | [itemId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: remove.url(args, options),
    method: 'delete',
})

remove.definition = {
    methods: ["delete"],
    url: '/api/cart/remove/{itemId}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \Vortex\Cart\Http\Controllers\Api\CartController::remove
 * @see packages/Cart/Http/Controllers/Api/CartController.php:124
 * @route '/api/cart/remove/{itemId}'
 */
remove.url = (args: { itemId: string | number } | [itemId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { itemId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    itemId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        itemId: args.itemId,
                }

    return remove.definition.url
            .replace('{itemId}', parsedArgs.itemId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Vortex\Cart\Http\Controllers\Api\CartController::remove
 * @see packages/Cart/Http/Controllers/Api/CartController.php:124
 * @route '/api/cart/remove/{itemId}'
 */
remove.delete = (args: { itemId: string | number } | [itemId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: remove.url(args, options),
    method: 'delete',
})

    /**
* @see \Vortex\Cart\Http\Controllers\Api\CartController::remove
 * @see packages/Cart/Http/Controllers/Api/CartController.php:124
 * @route '/api/cart/remove/{itemId}'
 */
    const removeForm = (args: { itemId: string | number } | [itemId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: remove.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \Vortex\Cart\Http\Controllers\Api\CartController::remove
 * @see packages/Cart/Http/Controllers/Api/CartController.php:124
 * @route '/api/cart/remove/{itemId}'
 */
        removeForm.delete = (args: { itemId: string | number } | [itemId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: remove.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    remove.form = removeForm
/**
* @see \Vortex\Cart\Http\Controllers\Api\CartController::clear
 * @see packages/Cart/Http/Controllers/Api/CartController.php:147
 * @route '/api/cart/clear'
 */
export const clear = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: clear.url(options),
    method: 'delete',
})

clear.definition = {
    methods: ["delete"],
    url: '/api/cart/clear',
} satisfies RouteDefinition<["delete"]>

/**
* @see \Vortex\Cart\Http\Controllers\Api\CartController::clear
 * @see packages/Cart/Http/Controllers/Api/CartController.php:147
 * @route '/api/cart/clear'
 */
clear.url = (options?: RouteQueryOptions) => {
    return clear.definition.url + queryParams(options)
}

/**
* @see \Vortex\Cart\Http\Controllers\Api\CartController::clear
 * @see packages/Cart/Http/Controllers/Api/CartController.php:147
 * @route '/api/cart/clear'
 */
clear.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: clear.url(options),
    method: 'delete',
})

    /**
* @see \Vortex\Cart\Http\Controllers\Api\CartController::clear
 * @see packages/Cart/Http/Controllers/Api/CartController.php:147
 * @route '/api/cart/clear'
 */
    const clearForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: clear.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \Vortex\Cart\Http\Controllers\Api\CartController::clear
 * @see packages/Cart/Http/Controllers/Api/CartController.php:147
 * @route '/api/cart/clear'
 */
        clearForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: clear.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    clear.form = clearForm
const cart = {
    index: Object.assign(index, index),
add: Object.assign(add, add),
update: Object.assign(update, update),
remove: Object.assign(remove, remove),
clear: Object.assign(clear, clear),
}

export default cart