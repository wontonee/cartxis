import cart from './cart'
const api = {
    cart: Object.assign(cart, cart),
}

export default api