import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import products from './products'
import categories from './categories'
/**
* @see \Vortex\Shop\Http\Controllers\HomeController::home
 * @see packages/Shop/Http/Controllers/HomeController.php:31
 * @route '/'
 */
export const home = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})

home.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Vortex\Shop\Http\Controllers\HomeController::home
 * @see packages/Shop/Http/Controllers/HomeController.php:31
 * @route '/'
 */
home.url = (options?: RouteQueryOptions) => {
    return home.definition.url + queryParams(options)
}

/**
* @see \Vortex\Shop\Http\Controllers\HomeController::home
 * @see packages/Shop/Http/Controllers/HomeController.php:31
 * @route '/'
 */
home.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})
/**
* @see \Vortex\Shop\Http\Controllers\HomeController::home
 * @see packages/Shop/Http/Controllers/HomeController.php:31
 * @route '/'
 */
home.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: home.url(options),
    method: 'head',
})

    /**
* @see \Vortex\Shop\Http\Controllers\HomeController::home
 * @see packages/Shop/Http/Controllers/HomeController.php:31
 * @route '/'
 */
    const homeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: home.url(options),
        method: 'get',
    })

            /**
* @see \Vortex\Shop\Http\Controllers\HomeController::home
 * @see packages/Shop/Http/Controllers/HomeController.php:31
 * @route '/'
 */
        homeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url(options),
            method: 'get',
        })
            /**
* @see \Vortex\Shop\Http\Controllers\HomeController::home
 * @see packages/Shop/Http/Controllers/HomeController.php:31
 * @route '/'
 */
        homeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    home.form = homeForm
/**
* @see \Vortex\Shop\Http\Controllers\SearchController::search
 * @see packages/Shop/Http/Controllers/SearchController.php:32
 * @route '/search'
 */
export const search = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: search.url(options),
    method: 'get',
})

search.definition = {
    methods: ["get","head"],
    url: '/search',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Vortex\Shop\Http\Controllers\SearchController::search
 * @see packages/Shop/Http/Controllers/SearchController.php:32
 * @route '/search'
 */
search.url = (options?: RouteQueryOptions) => {
    return search.definition.url + queryParams(options)
}

/**
* @see \Vortex\Shop\Http\Controllers\SearchController::search
 * @see packages/Shop/Http/Controllers/SearchController.php:32
 * @route '/search'
 */
search.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: search.url(options),
    method: 'get',
})
/**
* @see \Vortex\Shop\Http\Controllers\SearchController::search
 * @see packages/Shop/Http/Controllers/SearchController.php:32
 * @route '/search'
 */
search.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: search.url(options),
    method: 'head',
})

    /**
* @see \Vortex\Shop\Http\Controllers\SearchController::search
 * @see packages/Shop/Http/Controllers/SearchController.php:32
 * @route '/search'
 */
    const searchForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: search.url(options),
        method: 'get',
    })

            /**
* @see \Vortex\Shop\Http\Controllers\SearchController::search
 * @see packages/Shop/Http/Controllers/SearchController.php:32
 * @route '/search'
 */
        searchForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: search.url(options),
            method: 'get',
        })
            /**
* @see \Vortex\Shop\Http\Controllers\SearchController::search
 * @see packages/Shop/Http/Controllers/SearchController.php:32
 * @route '/search'
 */
        searchForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: search.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    search.form = searchForm
const shop = {
    products: Object.assign(products, products),
home: Object.assign(home, home),
categories: Object.assign(categories, categories),
search: Object.assign(search, search),
}

export default shop