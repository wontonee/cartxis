import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \Vortex\Shop\Http\Controllers\CategoryController::show
 * @see packages/Shop/Http/Controllers/CategoryController.php:43
 * @route '/category/{slug}'
 */
export const show = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/category/{slug}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Vortex\Shop\Http\Controllers\CategoryController::show
 * @see packages/Shop/Http/Controllers/CategoryController.php:43
 * @route '/category/{slug}'
 */
show.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return show.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Vortex\Shop\Http\Controllers\CategoryController::show
 * @see packages/Shop/Http/Controllers/CategoryController.php:43
 * @route '/category/{slug}'
 */
show.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \Vortex\Shop\Http\Controllers\CategoryController::show
 * @see packages/Shop/Http/Controllers/CategoryController.php:43
 * @route '/category/{slug}'
 */
show.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \Vortex\Shop\Http\Controllers\CategoryController::show
 * @see packages/Shop/Http/Controllers/CategoryController.php:43
 * @route '/category/{slug}'
 */
    const showForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \Vortex\Shop\Http\Controllers\CategoryController::show
 * @see packages/Shop/Http/Controllers/CategoryController.php:43
 * @route '/category/{slug}'
 */
        showForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \Vortex\Shop\Http\Controllers\CategoryController::show
 * @see packages/Shop/Http/Controllers/CategoryController.php:43
 * @route '/category/{slug}'
 */
        showForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const categories = {
    show: Object.assign(show, show),
}

export default categories