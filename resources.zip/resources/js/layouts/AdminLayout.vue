<script setup lang="ts">
import { ref, computed } from 'vue'
import { Link, usePage } from '@inertiajs/vue3'
import admin from '@/routes/admin'
import Toast from '@/Components/Toast.vue'
import { useMenuIcons } from '@/composables/useMenuIcons'
import {
  Menu,
  ChevronDown,
  LogOut,
  Search,
  Bell,
  ChevronLeft,
  ChevronRight,
  User,
  UserCircle,
  Settings
} from 'lucide-vue-next'

defineProps<{
  title?: string
}>()

const page = usePage()
const { getIcon } = useMenuIcons()
const sidebarOpen = ref(false)
const sidebarCollapsed = ref(false)
const userMenuOpen = ref(false)

// Track which parent menus are open
const openMenus = ref<Set<number>>(new Set())

// Get menu items from shared data
const menuItems = computed(() => {
  return page.props.menu?.admin || []
})

// Helper function to check if menu item is active
const isActive = (item: any) => {
  if (!item || !item.full_url) return false
  
  try {
    const currentUrl = page.url
    const menuUrl = item.full_url
    
    // Remove trailing slashes for comparison
    const cleanCurrentUrl = currentUrl.replace(/\/$/, '')
    const cleanMenuUrl = menuUrl.replace(/\/$/, '')
    
    // Exact match (most common case)
    if (cleanCurrentUrl === cleanMenuUrl) return true
    
    // Check if current URL starts with menu URL (for child routes)
    // Only match if followed by a slash to prevent partial matches
    if (cleanCurrentUrl.startsWith(cleanMenuUrl + '/')) return true
    
    return false
  } catch (error) {
    console.error('Error in isActive:', error)
    return false
  }
}

// Check if any child is active
const hasActiveChild = (item: any): boolean => {
  if (item.children && item.children.length > 0) {
    return item.children.some((child: any) => 
      isActive(child) || hasActiveChild(child)
    )
  }
  return false
}

// Initialize open menus based on active routes
const initializeOpenMenus = () => {
  menuItems.value.forEach((item: any) => {
    if (hasActiveChild(item)) {
      openMenus.value.add(item.id)
    }
  })
}

// Call on mount
initializeOpenMenus()

const toggleMenu = (itemId: number) => {
  if (openMenus.value.has(itemId)) {
    openMenus.value.delete(itemId)
  } else {
    openMenus.value.add(itemId)
  }
}

const isMenuOpen = (itemId: number) => {
  return openMenus.value.has(itemId)
}

const toggleSidebar = () => {
  sidebarCollapsed.value = !sidebarCollapsed.value
}
</script>

<template>
  <div class="min-h-screen bg-gray-100 dark:bg-gray-900">
    <!-- Sidebar -->
    <aside
      :class="[
        'fixed inset-y-0 left-0 z-50 bg-gray-900 transform transition-all duration-200 ease-in-out',
        sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0',
        sidebarCollapsed ? 'w-20' : 'w-64'
      ]"
    >
      <!-- Logo -->
      <div class="flex items-center justify-between h-16 px-6 border-b border-gray-800">
        <Link :href="admin.dashboard.url()" class="flex items-center space-x-3">
          <div class="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
            <span class="text-white font-bold text-xl">V</span>
          </div>
          <span v-if="!sidebarCollapsed" class="text-white font-semibold text-lg transition-opacity duration-200">Vortex</span>
        </Link>
        
        <!-- Desktop Toggle Button -->
        <button
          @click="toggleSidebar"
          class="hidden lg:flex items-center justify-center w-8 h-8 text-gray-400 hover:text-white hover:bg-gray-800 rounded-lg transition-colors"
        >
          <ChevronLeft v-if="!sidebarCollapsed" class="w-5 h-5" />
          <ChevronRight v-if="sidebarCollapsed" class="w-5 h-5" />
        </button>
      </div>

      <!-- Navigation -->
      <nav class="flex-1 px-4 py-6 space-y-1 overflow-y-auto h-[calc(100vh-4rem)]">
        <!-- Dynamic Menu Items -->
        <template v-for="item in menuItems" :key="item.id">
          <!-- Parent Menu without children (Direct Link) -->
          <Link
            v-if="!item.children || item.children.length === 0"
            :href="item.full_url || '#'"
            :class="[
              'flex items-center px-4 py-3 text-gray-300 rounded-lg hover:bg-gray-800 hover:text-white transition-colors',
              { 'bg-blue-600 text-white': isActive(item) },
              sidebarCollapsed && 'justify-center'
            ]"
            :title="sidebarCollapsed ? item.title : ''"
          >
            <component 
              :is="getIcon(item.icon)" 
              v-if="item.icon"
              class="w-5 h-5 flex-shrink-0" 
              :class="{ 'mr-3': !sidebarCollapsed }" 
            />
            <span v-if="!sidebarCollapsed">{{ item.title }}</span>
          </Link>

          <!-- Parent Menu with children (Expandable) -->
          <div v-else>
            <button
              @click="toggleMenu(item.id)"
              :class="[
                'w-full flex items-center px-4 py-3 text-gray-300 rounded-lg hover:bg-gray-800 hover:text-white transition-colors',
                sidebarCollapsed && 'justify-center'
              ]"
              :title="sidebarCollapsed ? item.title : ''"
            >
              <component 
                :is="getIcon(item.icon)" 
                v-if="item.icon"
                class="w-5 h-5 flex-shrink-0" 
                :class="{ 'mr-3': !sidebarCollapsed }" 
              />
              <span v-if="!sidebarCollapsed" class="flex-1 text-left">{{ item.title }}</span>
              <ChevronDown 
                v-if="!sidebarCollapsed" 
                :class="['w-4 h-4 transition-transform', isMenuOpen(item.id) && 'rotate-180']" 
              />
            </button>
            
            <!-- Child Menu Items -->
            <div v-if="!sidebarCollapsed" v-show="isMenuOpen(item.id)" class="ml-4 mt-1 space-y-1">
              <Link 
                v-for="child in item.children" 
                :key="child.id"
                :href="child.full_url || '#'" 
                :class="[
                  'flex items-center px-4 py-2 rounded-lg transition-colors cursor-pointer',
                  isActive(child)
                    ? 'bg-blue-600 text-white' 
                    : 'text-gray-400 hover:text-white hover:bg-gray-800'
                ]"
              >
                <component 
                  :is="getIcon(child.icon)" 
                  v-if="child.icon"
                  class="w-4 h-4 mr-3" 
                />
                <span class="text-sm">{{ child.title }}</span>
              </Link>
            </div>
          </div>
        </template>
      </nav>
    </aside>

    <!-- Main Content -->
    <div :class="['transition-all duration-200', sidebarCollapsed ? 'lg:pl-20' : 'lg:pl-64']">
      <!-- Header -->
      <header class="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 sticky top-0 z-40">
        <div class="px-4 sm:px-6 lg:px-8">
          <div class="flex items-center justify-between h-16">
            <!-- Mobile menu button -->
            <button
              @click="sidebarOpen = !sidebarOpen"
              class="lg:hidden text-gray-500 hover:text-gray-600 dark:text-gray-400 dark:hover:text-gray-300"
            >
              <Menu class="w-6 h-6" />
            </button>

            <!-- Page title -->
            <h1 class="text-xl font-semibold text-gray-900 dark:text-white">
              {{ title || 'Dashboard' }}
            </h1>

            <!-- Right side -->
            <div class="flex items-center space-x-4">
              <!-- Search -->
              <button class="text-gray-500 hover:text-gray-600 dark:text-gray-400 dark:hover:text-gray-300">
                <Search class="w-5 h-5" />
              </button>

              <!-- Notifications -->
              <button class="relative text-gray-500 hover:text-gray-600 dark:text-gray-400 dark:hover:text-gray-300">
                <Bell class="w-5 h-5" />
                <span class="absolute top-0 right-0 block h-2 w-2 rounded-full bg-red-500 ring-2 ring-white dark:ring-gray-800"></span>
              </button>

              <!-- User Dropdown Menu -->
              <div class="relative">
                <button
                  @click="userMenuOpen = !userMenuOpen"
                  class="flex items-center space-x-3 focus:outline-none"
                >
                  <div class="text-right hidden sm:block">
                    <div class="text-sm font-medium text-gray-900 dark:text-white">
                      {{ page.props.auth?.user?.name || 'Admin' }}
                    </div>
                    <div class="text-xs text-gray-500 dark:text-gray-400">
                      {{ page.props.auth?.user?.email }}
                    </div>
                  </div>
                  <div class="flex items-center justify-center w-10 h-10 rounded-full bg-blue-600 text-white hover:bg-blue-700 transition-colors">
                    <UserCircle class="w-6 h-6" />
                  </div>
                </button>

                <!-- Dropdown Menu -->
                <Transition
                  enter-active-class="transition ease-out duration-100"
                  enter-from-class="transform opacity-0 scale-95"
                  enter-to-class="transform opacity-100 scale-100"
                  leave-active-class="transition ease-in duration-75"
                  leave-from-class="transform opacity-100 scale-100"
                  leave-to-class="transform opacity-0 scale-95"
                >
                  <div
                    v-show="userMenuOpen"
                    class="absolute right-0 mt-2 w-56 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 py-1"
                  >
                    <div class="px-4 py-3 border-b border-gray-200 dark:border-gray-700">
                      <p class="text-sm font-medium text-gray-900 dark:text-white">
                        {{ page.props.auth?.user?.name || 'Admin' }}
                      </p>
                      <p class="text-xs text-gray-500 dark:text-gray-400 truncate">
                        {{ page.props.auth?.user?.email }}
                      </p>
                    </div>
                    
                    <a href="#" class="flex items-center px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
                      <User class="w-4 h-4 mr-3" />
                      Profile
                    </a>
                    
                    <a href="#" class="flex items-center px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
                      <Settings class="w-4 h-4 mr-3" />
                      Account Settings
                    </a>
                    
                    <div class="border-t border-gray-200 dark:border-gray-700 my-1"></div>
                    
                    <Link
                      :href="admin.logout.url()"
                      method="post"
                      as="button"
                      class="w-full flex items-center px-4 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-gray-100 dark:hover:bg-gray-700"
                    >
                      <LogOut class="w-4 h-4 mr-3" />
                      Logout
                    </Link>
                  </div>
                </Transition>
              </div>
            </div>
          </div>
        </div>
      </header>

      <!-- Page Content -->
      <main class="p-4 sm:p-6 lg:p-8">
        <slot />
      </main>
    </div>

    <!-- Mobile sidebar overlay -->
    <div
      v-if="sidebarOpen"
      @click="sidebarOpen = false"
      class="fixed inset-0 z-40 bg-gray-600 bg-opacity-75 lg:hidden"
    ></div>

    <!-- Toast Notifications -->
    <Toast />
  </div>
</template>
