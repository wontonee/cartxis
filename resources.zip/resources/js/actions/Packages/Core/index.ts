import Http from './Http'
const Core = {
    Http: Object.assign(Http, Http),
}

export default Core