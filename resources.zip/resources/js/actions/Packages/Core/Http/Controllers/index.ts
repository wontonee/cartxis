import Admin from './Admin'
const Controllers = {
    Admin: Object.assign(Admin, Admin),
}

export default Controllers