import ThemeController from './ThemeController'
const Admin = {
    ThemeController: Object.assign(ThemeController, ThemeController),
}

export default Admin