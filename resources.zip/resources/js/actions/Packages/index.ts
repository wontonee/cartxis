import Core from './Core'
const Packages = {
    Core: Object.assign(Core, Core),
}

export default Packages