import CartController from './CartController'
import Api from './Api'
const Controllers = {
    CartController: Object.assign(CartController, CartController),
Api: Object.assign(Api, Api),
}

export default Controllers