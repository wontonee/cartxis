import CartController from './CartController'
const Api = {
    CartController: Object.assign(CartController, CartController),
}

export default Api