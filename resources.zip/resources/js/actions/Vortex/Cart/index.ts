import Http from './Http'
const Cart = {
    Http: Object.assign(Http, Http),
}

export default Cart