import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::index
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:18
 * @route '/admin/catalog/reviews'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/catalog/reviews',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::index
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:18
 * @route '/admin/catalog/reviews'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::index
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:18
 * @route '/admin/catalog/reviews'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::index
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:18
 * @route '/admin/catalog/reviews'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::index
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:18
 * @route '/admin/catalog/reviews'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::index
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:18
 * @route '/admin/catalog/reviews'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::index
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:18
 * @route '/admin/catalog/reviews'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::show
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:106
 * @route '/admin/catalog/reviews/{review}'
 */
export const show = (args: { review: number | { id: number } } | [review: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/catalog/reviews/{review}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::show
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:106
 * @route '/admin/catalog/reviews/{review}'
 */
show.url = (args: { review: number | { id: number } } | [review: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { review: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { review: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    review: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        review: typeof args.review === 'object'
                ? args.review.id
                : args.review,
                }

    return show.definition.url
            .replace('{review}', parsedArgs.review.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::show
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:106
 * @route '/admin/catalog/reviews/{review}'
 */
show.get = (args: { review: number | { id: number } } | [review: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::show
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:106
 * @route '/admin/catalog/reviews/{review}'
 */
show.head = (args: { review: number | { id: number } } | [review: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::show
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:106
 * @route '/admin/catalog/reviews/{review}'
 */
    const showForm = (args: { review: number | { id: number } } | [review: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::show
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:106
 * @route '/admin/catalog/reviews/{review}'
 */
        showForm.get = (args: { review: number | { id: number } } | [review: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::show
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:106
 * @route '/admin/catalog/reviews/{review}'
 */
        showForm.head = (args: { review: number | { id: number } } | [review: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::destroy
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:210
 * @route '/admin/catalog/reviews/{review}'
 */
export const destroy = (args: { review: number | { id: number } } | [review: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/catalog/reviews/{review}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::destroy
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:210
 * @route '/admin/catalog/reviews/{review}'
 */
destroy.url = (args: { review: number | { id: number } } | [review: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { review: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { review: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    review: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        review: typeof args.review === 'object'
                ? args.review.id
                : args.review,
                }

    return destroy.definition.url
            .replace('{review}', parsedArgs.review.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::destroy
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:210
 * @route '/admin/catalog/reviews/{review}'
 */
destroy.delete = (args: { review: number | { id: number } } | [review: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::destroy
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:210
 * @route '/admin/catalog/reviews/{review}'
 */
    const destroyForm = (args: { review: number | { id: number } } | [review: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::destroy
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:210
 * @route '/admin/catalog/reviews/{review}'
 */
        destroyForm.delete = (args: { review: number | { id: number } } | [review: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::updateStatus
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:143
 * @route '/admin/catalog/reviews/{review}/status'
 */
export const updateStatus = (args: { review: number | { id: number } } | [review: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateStatus.url(args, options),
    method: 'post',
})

updateStatus.definition = {
    methods: ["post"],
    url: '/admin/catalog/reviews/{review}/status',
} satisfies RouteDefinition<["post"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::updateStatus
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:143
 * @route '/admin/catalog/reviews/{review}/status'
 */
updateStatus.url = (args: { review: number | { id: number } } | [review: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { review: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { review: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    review: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        review: typeof args.review === 'object'
                ? args.review.id
                : args.review,
                }

    return updateStatus.definition.url
            .replace('{review}', parsedArgs.review.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::updateStatus
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:143
 * @route '/admin/catalog/reviews/{review}/status'
 */
updateStatus.post = (args: { review: number | { id: number } } | [review: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateStatus.url(args, options),
    method: 'post',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::updateStatus
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:143
 * @route '/admin/catalog/reviews/{review}/status'
 */
    const updateStatusForm = (args: { review: number | { id: number } } | [review: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateStatus.url(args, options),
        method: 'post',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::updateStatus
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:143
 * @route '/admin/catalog/reviews/{review}/status'
 */
        updateStatusForm.post = (args: { review: number | { id: number } } | [review: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateStatus.url(args, options),
            method: 'post',
        })
    
    updateStatus.form = updateStatusForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::reply
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:158
 * @route '/admin/catalog/reviews/{review}/reply'
 */
export const reply = (args: { review: number | { id: number } } | [review: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reply.url(args, options),
    method: 'post',
})

reply.definition = {
    methods: ["post"],
    url: '/admin/catalog/reviews/{review}/reply',
} satisfies RouteDefinition<["post"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::reply
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:158
 * @route '/admin/catalog/reviews/{review}/reply'
 */
reply.url = (args: { review: number | { id: number } } | [review: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { review: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { review: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    review: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        review: typeof args.review === 'object'
                ? args.review.id
                : args.review,
                }

    return reply.definition.url
            .replace('{review}', parsedArgs.review.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::reply
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:158
 * @route '/admin/catalog/reviews/{review}/reply'
 */
reply.post = (args: { review: number | { id: number } } | [review: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reply.url(args, options),
    method: 'post',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::reply
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:158
 * @route '/admin/catalog/reviews/{review}/reply'
 */
    const replyForm = (args: { review: number | { id: number } } | [review: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reply.url(args, options),
        method: 'post',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::reply
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:158
 * @route '/admin/catalog/reviews/{review}/reply'
 */
        replyForm.post = (args: { review: number | { id: number } } | [review: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reply.url(args, options),
            method: 'post',
        })
    
    reply.form = replyForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::bulkAction
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:172
 * @route '/admin/catalog/reviews/bulk-action'
 */
export const bulkAction = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkAction.url(options),
    method: 'post',
})

bulkAction.definition = {
    methods: ["post"],
    url: '/admin/catalog/reviews/bulk-action',
} satisfies RouteDefinition<["post"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::bulkAction
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:172
 * @route '/admin/catalog/reviews/bulk-action'
 */
bulkAction.url = (options?: RouteQueryOptions) => {
    return bulkAction.definition.url + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::bulkAction
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:172
 * @route '/admin/catalog/reviews/bulk-action'
 */
bulkAction.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkAction.url(options),
    method: 'post',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::bulkAction
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:172
 * @route '/admin/catalog/reviews/bulk-action'
 */
    const bulkActionForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: bulkAction.url(options),
        method: 'post',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\ReviewController::bulkAction
 * @see packages/Product/Http/Controllers/Admin/ReviewController.php:172
 * @route '/admin/catalog/reviews/bulk-action'
 */
        bulkActionForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: bulkAction.url(options),
            method: 'post',
        })
    
    bulkAction.form = bulkActionForm
const ReviewController = { index, show, destroy, updateStatus, reply, bulkAction }

export default ReviewController