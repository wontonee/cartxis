import Admin from './Admin'
import FrontEnd from './FrontEnd'
const Controllers = {
    Admin: Object.assign(Admin, Admin),
FrontEnd: Object.assign(FrontEnd, FrontEnd),
}

export default Controllers