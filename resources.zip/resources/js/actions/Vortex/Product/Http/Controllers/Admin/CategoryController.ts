import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::index
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:19
 * @route '/admin/catalog/categories'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/catalog/categories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::index
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:19
 * @route '/admin/catalog/categories'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::index
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:19
 * @route '/admin/catalog/categories'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::index
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:19
 * @route '/admin/catalog/categories'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::index
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:19
 * @route '/admin/catalog/categories'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::index
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:19
 * @route '/admin/catalog/categories'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::index
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:19
 * @route '/admin/catalog/categories'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::create
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:63
 * @route '/admin/catalog/categories/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/catalog/categories/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::create
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:63
 * @route '/admin/catalog/categories/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::create
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:63
 * @route '/admin/catalog/categories/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::create
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:63
 * @route '/admin/catalog/categories/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::create
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:63
 * @route '/admin/catalog/categories/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::create
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:63
 * @route '/admin/catalog/categories/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::create
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:63
 * @route '/admin/catalog/categories/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::store
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:73
 * @route '/admin/catalog/categories'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/catalog/categories',
} satisfies RouteDefinition<["post"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::store
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:73
 * @route '/admin/catalog/categories'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::store
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:73
 * @route '/admin/catalog/categories'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::store
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:73
 * @route '/admin/catalog/categories'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::store
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:73
 * @route '/admin/catalog/categories'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::show
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:113
 * @route '/admin/catalog/categories/{category}'
 */
export const show = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/catalog/categories/{category}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::show
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:113
 * @route '/admin/catalog/categories/{category}'
 */
show.url = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { category: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        category: typeof args.category === 'object'
                ? args.category.id
                : args.category,
                }

    return show.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::show
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:113
 * @route '/admin/catalog/categories/{category}'
 */
show.get = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::show
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:113
 * @route '/admin/catalog/categories/{category}'
 */
show.head = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::show
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:113
 * @route '/admin/catalog/categories/{category}'
 */
    const showForm = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::show
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:113
 * @route '/admin/catalog/categories/{category}'
 */
        showForm.get = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::show
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:113
 * @route '/admin/catalog/categories/{category}'
 */
        showForm.head = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::edit
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:125
 * @route '/admin/catalog/categories/{category}/edit'
 */
export const edit = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/catalog/categories/{category}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::edit
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:125
 * @route '/admin/catalog/categories/{category}/edit'
 */
edit.url = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { category: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        category: typeof args.category === 'object'
                ? args.category.id
                : args.category,
                }

    return edit.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::edit
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:125
 * @route '/admin/catalog/categories/{category}/edit'
 */
edit.get = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::edit
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:125
 * @route '/admin/catalog/categories/{category}/edit'
 */
edit.head = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::edit
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:125
 * @route '/admin/catalog/categories/{category}/edit'
 */
    const editForm = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::edit
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:125
 * @route '/admin/catalog/categories/{category}/edit'
 */
        editForm.get = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::edit
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:125
 * @route '/admin/catalog/categories/{category}/edit'
 */
        editForm.head = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::update
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:138
 * @route '/admin/catalog/categories/{category}'
 */
export const update = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/catalog/categories/{category}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::update
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:138
 * @route '/admin/catalog/categories/{category}'
 */
update.url = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { category: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        category: typeof args.category === 'object'
                ? args.category.id
                : args.category,
                }

    return update.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::update
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:138
 * @route '/admin/catalog/categories/{category}'
 */
update.put = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::update
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:138
 * @route '/admin/catalog/categories/{category}'
 */
update.patch = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::update
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:138
 * @route '/admin/catalog/categories/{category}'
 */
    const updateForm = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::update
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:138
 * @route '/admin/catalog/categories/{category}'
 */
        updateForm.put = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::update
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:138
 * @route '/admin/catalog/categories/{category}'
 */
        updateForm.patch = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::destroy
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:184
 * @route '/admin/catalog/categories/{category}'
 */
export const destroy = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/catalog/categories/{category}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::destroy
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:184
 * @route '/admin/catalog/categories/{category}'
 */
destroy.url = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { category: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        category: typeof args.category === 'object'
                ? args.category.id
                : args.category,
                }

    return destroy.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::destroy
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:184
 * @route '/admin/catalog/categories/{category}'
 */
destroy.delete = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::destroy
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:184
 * @route '/admin/catalog/categories/{category}'
 */
    const destroyForm = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::destroy
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:184
 * @route '/admin/catalog/categories/{category}'
 */
        destroyForm.delete = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::bulkDestroy
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:205
 * @route '/admin/catalog/categories/bulk-destroy'
 */
export const bulkDestroy = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkDestroy.url(options),
    method: 'post',
})

bulkDestroy.definition = {
    methods: ["post"],
    url: '/admin/catalog/categories/bulk-destroy',
} satisfies RouteDefinition<["post"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::bulkDestroy
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:205
 * @route '/admin/catalog/categories/bulk-destroy'
 */
bulkDestroy.url = (options?: RouteQueryOptions) => {
    return bulkDestroy.definition.url + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::bulkDestroy
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:205
 * @route '/admin/catalog/categories/bulk-destroy'
 */
bulkDestroy.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkDestroy.url(options),
    method: 'post',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::bulkDestroy
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:205
 * @route '/admin/catalog/categories/bulk-destroy'
 */
    const bulkDestroyForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: bulkDestroy.url(options),
        method: 'post',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::bulkDestroy
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:205
 * @route '/admin/catalog/categories/bulk-destroy'
 */
        bulkDestroyForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: bulkDestroy.url(options),
            method: 'post',
        })
    
    bulkDestroy.form = bulkDestroyForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::bulkUpdateStatus
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:244
 * @route '/admin/catalog/categories/bulk-status'
 */
export const bulkUpdateStatus = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkUpdateStatus.url(options),
    method: 'post',
})

bulkUpdateStatus.definition = {
    methods: ["post"],
    url: '/admin/catalog/categories/bulk-status',
} satisfies RouteDefinition<["post"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::bulkUpdateStatus
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:244
 * @route '/admin/catalog/categories/bulk-status'
 */
bulkUpdateStatus.url = (options?: RouteQueryOptions) => {
    return bulkUpdateStatus.definition.url + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::bulkUpdateStatus
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:244
 * @route '/admin/catalog/categories/bulk-status'
 */
bulkUpdateStatus.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkUpdateStatus.url(options),
    method: 'post',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::bulkUpdateStatus
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:244
 * @route '/admin/catalog/categories/bulk-status'
 */
    const bulkUpdateStatusForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: bulkUpdateStatus.url(options),
        method: 'post',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\CategoryController::bulkUpdateStatus
 * @see packages/Product/Http/Controllers/Admin/CategoryController.php:244
 * @route '/admin/catalog/categories/bulk-status'
 */
        bulkUpdateStatusForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: bulkUpdateStatus.url(options),
            method: 'post',
        })
    
    bulkUpdateStatus.form = bulkUpdateStatusForm
const CategoryController = { index, create, store, show, edit, update, destroy, bulkDestroy, bulkUpdateStatus }

export default CategoryController