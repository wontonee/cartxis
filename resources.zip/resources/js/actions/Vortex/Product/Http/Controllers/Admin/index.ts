import ProductController from './ProductController'
import ProductImageController from './ProductImageController'
import CategoryController from './CategoryController'
import AttributeController from './AttributeController'
import BrandController from './BrandController'
import ReviewController from './ReviewController'
const Admin = {
    ProductController: Object.assign(ProductController, ProductController),
ProductImageController: Object.assign(ProductImageController, ProductImageController),
CategoryController: Object.assign(CategoryController, CategoryController),
AttributeController: Object.assign(AttributeController, AttributeController),
BrandController: Object.assign(BrandController, BrandController),
ReviewController: Object.assign(ReviewController, ReviewController),
}

export default Admin