import ProductController from './ProductController'
const FrontEnd = {
    ProductController: Object.assign(ProductController, ProductController),
}

export default FrontEnd