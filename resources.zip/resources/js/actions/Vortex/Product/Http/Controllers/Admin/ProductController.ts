import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::index
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:18
 * @route '/admin/catalog/products'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/catalog/products',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::index
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:18
 * @route '/admin/catalog/products'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::index
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:18
 * @route '/admin/catalog/products'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::index
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:18
 * @route '/admin/catalog/products'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::index
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:18
 * @route '/admin/catalog/products'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::index
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:18
 * @route '/admin/catalog/products'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::index
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:18
 * @route '/admin/catalog/products'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::create
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:66
 * @route '/admin/catalog/products/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/catalog/products/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::create
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:66
 * @route '/admin/catalog/products/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::create
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:66
 * @route '/admin/catalog/products/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::create
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:66
 * @route '/admin/catalog/products/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::create
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:66
 * @route '/admin/catalog/products/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::create
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:66
 * @route '/admin/catalog/products/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::create
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:66
 * @route '/admin/catalog/products/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::store
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:84
 * @route '/admin/catalog/products'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/catalog/products',
} satisfies RouteDefinition<["post"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::store
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:84
 * @route '/admin/catalog/products'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::store
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:84
 * @route '/admin/catalog/products'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::store
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:84
 * @route '/admin/catalog/products'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::store
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:84
 * @route '/admin/catalog/products'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::show
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:0
 * @route '/admin/catalog/products/{product}'
 */
export const show = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/catalog/products/{product}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::show
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:0
 * @route '/admin/catalog/products/{product}'
 */
show.url = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    product: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        product: args.product,
                }

    return show.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::show
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:0
 * @route '/admin/catalog/products/{product}'
 */
show.get = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::show
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:0
 * @route '/admin/catalog/products/{product}'
 */
show.head = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::show
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:0
 * @route '/admin/catalog/products/{product}'
 */
    const showForm = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::show
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:0
 * @route '/admin/catalog/products/{product}'
 */
        showForm.get = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::show
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:0
 * @route '/admin/catalog/products/{product}'
 */
        showForm.head = (args: { product: string | number } | [product: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::edit
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:157
 * @route '/admin/catalog/products/{product}/edit'
 */
export const edit = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/catalog/products/{product}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::edit
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:157
 * @route '/admin/catalog/products/{product}/edit'
 */
edit.url = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { product: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    product: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        product: typeof args.product === 'object'
                ? args.product.id
                : args.product,
                }

    return edit.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::edit
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:157
 * @route '/admin/catalog/products/{product}/edit'
 */
edit.get = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::edit
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:157
 * @route '/admin/catalog/products/{product}/edit'
 */
edit.head = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::edit
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:157
 * @route '/admin/catalog/products/{product}/edit'
 */
    const editForm = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::edit
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:157
 * @route '/admin/catalog/products/{product}/edit'
 */
        editForm.get = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::edit
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:157
 * @route '/admin/catalog/products/{product}/edit'
 */
        editForm.head = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::update
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:186
 * @route '/admin/catalog/products/{product}'
 */
export const update = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/catalog/products/{product}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::update
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:186
 * @route '/admin/catalog/products/{product}'
 */
update.url = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { product: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    product: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        product: typeof args.product === 'object'
                ? args.product.id
                : args.product,
                }

    return update.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::update
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:186
 * @route '/admin/catalog/products/{product}'
 */
update.put = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::update
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:186
 * @route '/admin/catalog/products/{product}'
 */
update.patch = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::update
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:186
 * @route '/admin/catalog/products/{product}'
 */
    const updateForm = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::update
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:186
 * @route '/admin/catalog/products/{product}'
 */
        updateForm.put = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::update
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:186
 * @route '/admin/catalog/products/{product}'
 */
        updateForm.patch = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::destroy
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:340
 * @route '/admin/catalog/products/{product}'
 */
export const destroy = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/catalog/products/{product}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::destroy
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:340
 * @route '/admin/catalog/products/{product}'
 */
destroy.url = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { product: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    product: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        product: typeof args.product === 'object'
                ? args.product.id
                : args.product,
                }

    return destroy.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::destroy
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:340
 * @route '/admin/catalog/products/{product}'
 */
destroy.delete = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::destroy
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:340
 * @route '/admin/catalog/products/{product}'
 */
    const destroyForm = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::destroy
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:340
 * @route '/admin/catalog/products/{product}'
 */
        destroyForm.delete = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::bulkDestroy
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:352
 * @route '/admin/catalog/products/bulk-destroy'
 */
export const bulkDestroy = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkDestroy.url(options),
    method: 'post',
})

bulkDestroy.definition = {
    methods: ["post"],
    url: '/admin/catalog/products/bulk-destroy',
} satisfies RouteDefinition<["post"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::bulkDestroy
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:352
 * @route '/admin/catalog/products/bulk-destroy'
 */
bulkDestroy.url = (options?: RouteQueryOptions) => {
    return bulkDestroy.definition.url + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::bulkDestroy
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:352
 * @route '/admin/catalog/products/bulk-destroy'
 */
bulkDestroy.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkDestroy.url(options),
    method: 'post',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::bulkDestroy
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:352
 * @route '/admin/catalog/products/bulk-destroy'
 */
    const bulkDestroyForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: bulkDestroy.url(options),
        method: 'post',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::bulkDestroy
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:352
 * @route '/admin/catalog/products/bulk-destroy'
 */
        bulkDestroyForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: bulkDestroy.url(options),
            method: 'post',
        })
    
    bulkDestroy.form = bulkDestroyForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::bulkUpdateStatus
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:369
 * @route '/admin/catalog/products/bulk-status'
 */
export const bulkUpdateStatus = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkUpdateStatus.url(options),
    method: 'post',
})

bulkUpdateStatus.definition = {
    methods: ["post"],
    url: '/admin/catalog/products/bulk-status',
} satisfies RouteDefinition<["post"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::bulkUpdateStatus
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:369
 * @route '/admin/catalog/products/bulk-status'
 */
bulkUpdateStatus.url = (options?: RouteQueryOptions) => {
    return bulkUpdateStatus.definition.url + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::bulkUpdateStatus
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:369
 * @route '/admin/catalog/products/bulk-status'
 */
bulkUpdateStatus.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkUpdateStatus.url(options),
    method: 'post',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::bulkUpdateStatus
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:369
 * @route '/admin/catalog/products/bulk-status'
 */
    const bulkUpdateStatusForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: bulkUpdateStatus.url(options),
        method: 'post',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\ProductController::bulkUpdateStatus
 * @see packages/Product/Http/Controllers/Admin/ProductController.php:369
 * @route '/admin/catalog/products/bulk-status'
 */
        bulkUpdateStatusForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: bulkUpdateStatus.url(options),
            method: 'post',
        })
    
    bulkUpdateStatus.form = bulkUpdateStatusForm
const ProductController = { index, create, store, show, edit, update, destroy, bulkDestroy, bulkUpdateStatus }

export default ProductController