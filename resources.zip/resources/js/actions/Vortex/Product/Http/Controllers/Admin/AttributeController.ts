import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::index
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:19
 * @route '/admin/catalog/attributes'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/catalog/attributes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::index
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:19
 * @route '/admin/catalog/attributes'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::index
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:19
 * @route '/admin/catalog/attributes'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::index
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:19
 * @route '/admin/catalog/attributes'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::index
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:19
 * @route '/admin/catalog/attributes'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::index
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:19
 * @route '/admin/catalog/attributes'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::index
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:19
 * @route '/admin/catalog/attributes'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::create
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:52
 * @route '/admin/catalog/attributes/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/catalog/attributes/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::create
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:52
 * @route '/admin/catalog/attributes/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::create
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:52
 * @route '/admin/catalog/attributes/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::create
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:52
 * @route '/admin/catalog/attributes/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::create
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:52
 * @route '/admin/catalog/attributes/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::create
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:52
 * @route '/admin/catalog/attributes/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::create
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:52
 * @route '/admin/catalog/attributes/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::store
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:62
 * @route '/admin/catalog/attributes'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/catalog/attributes',
} satisfies RouteDefinition<["post"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::store
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:62
 * @route '/admin/catalog/attributes'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::store
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:62
 * @route '/admin/catalog/attributes'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::store
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:62
 * @route '/admin/catalog/attributes'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::store
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:62
 * @route '/admin/catalog/attributes'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::show
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:110
 * @route '/admin/catalog/attributes/{attribute}'
 */
export const show = (args: { attribute: number | { id: number } } | [attribute: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/catalog/attributes/{attribute}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::show
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:110
 * @route '/admin/catalog/attributes/{attribute}'
 */
show.url = (args: { attribute: number | { id: number } } | [attribute: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { attribute: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { attribute: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    attribute: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        attribute: typeof args.attribute === 'object'
                ? args.attribute.id
                : args.attribute,
                }

    return show.definition.url
            .replace('{attribute}', parsedArgs.attribute.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::show
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:110
 * @route '/admin/catalog/attributes/{attribute}'
 */
show.get = (args: { attribute: number | { id: number } } | [attribute: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::show
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:110
 * @route '/admin/catalog/attributes/{attribute}'
 */
show.head = (args: { attribute: number | { id: number } } | [attribute: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::show
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:110
 * @route '/admin/catalog/attributes/{attribute}'
 */
    const showForm = (args: { attribute: number | { id: number } } | [attribute: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::show
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:110
 * @route '/admin/catalog/attributes/{attribute}'
 */
        showForm.get = (args: { attribute: number | { id: number } } | [attribute: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::show
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:110
 * @route '/admin/catalog/attributes/{attribute}'
 */
        showForm.head = (args: { attribute: number | { id: number } } | [attribute: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::edit
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:122
 * @route '/admin/catalog/attributes/{attribute}/edit'
 */
export const edit = (args: { attribute: number | { id: number } } | [attribute: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/catalog/attributes/{attribute}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::edit
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:122
 * @route '/admin/catalog/attributes/{attribute}/edit'
 */
edit.url = (args: { attribute: number | { id: number } } | [attribute: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { attribute: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { attribute: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    attribute: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        attribute: typeof args.attribute === 'object'
                ? args.attribute.id
                : args.attribute,
                }

    return edit.definition.url
            .replace('{attribute}', parsedArgs.attribute.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::edit
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:122
 * @route '/admin/catalog/attributes/{attribute}/edit'
 */
edit.get = (args: { attribute: number | { id: number } } | [attribute: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::edit
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:122
 * @route '/admin/catalog/attributes/{attribute}/edit'
 */
edit.head = (args: { attribute: number | { id: number } } | [attribute: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::edit
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:122
 * @route '/admin/catalog/attributes/{attribute}/edit'
 */
    const editForm = (args: { attribute: number | { id: number } } | [attribute: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::edit
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:122
 * @route '/admin/catalog/attributes/{attribute}/edit'
 */
        editForm.get = (args: { attribute: number | { id: number } } | [attribute: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::edit
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:122
 * @route '/admin/catalog/attributes/{attribute}/edit'
 */
        editForm.head = (args: { attribute: number | { id: number } } | [attribute: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::update
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:134
 * @route '/admin/catalog/attributes/{attribute}'
 */
export const update = (args: { attribute: number | { id: number } } | [attribute: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/catalog/attributes/{attribute}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::update
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:134
 * @route '/admin/catalog/attributes/{attribute}'
 */
update.url = (args: { attribute: number | { id: number } } | [attribute: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { attribute: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { attribute: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    attribute: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        attribute: typeof args.attribute === 'object'
                ? args.attribute.id
                : args.attribute,
                }

    return update.definition.url
            .replace('{attribute}', parsedArgs.attribute.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::update
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:134
 * @route '/admin/catalog/attributes/{attribute}'
 */
update.put = (args: { attribute: number | { id: number } } | [attribute: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::update
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:134
 * @route '/admin/catalog/attributes/{attribute}'
 */
update.patch = (args: { attribute: number | { id: number } } | [attribute: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::update
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:134
 * @route '/admin/catalog/attributes/{attribute}'
 */
    const updateForm = (args: { attribute: number | { id: number } } | [attribute: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::update
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:134
 * @route '/admin/catalog/attributes/{attribute}'
 */
        updateForm.put = (args: { attribute: number | { id: number } } | [attribute: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::update
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:134
 * @route '/admin/catalog/attributes/{attribute}'
 */
        updateForm.patch = (args: { attribute: number | { id: number } } | [attribute: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::destroy
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:200
 * @route '/admin/catalog/attributes/{attribute}'
 */
export const destroy = (args: { attribute: number | { id: number } } | [attribute: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/catalog/attributes/{attribute}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::destroy
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:200
 * @route '/admin/catalog/attributes/{attribute}'
 */
destroy.url = (args: { attribute: number | { id: number } } | [attribute: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { attribute: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { attribute: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    attribute: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        attribute: typeof args.attribute === 'object'
                ? args.attribute.id
                : args.attribute,
                }

    return destroy.definition.url
            .replace('{attribute}', parsedArgs.attribute.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::destroy
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:200
 * @route '/admin/catalog/attributes/{attribute}'
 */
destroy.delete = (args: { attribute: number | { id: number } } | [attribute: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::destroy
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:200
 * @route '/admin/catalog/attributes/{attribute}'
 */
    const destroyForm = (args: { attribute: number | { id: number } } | [attribute: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::destroy
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:200
 * @route '/admin/catalog/attributes/{attribute}'
 */
        destroyForm.delete = (args: { attribute: number | { id: number } } | [attribute: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::bulkDestroy
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:216
 * @route '/admin/catalog/attributes/bulk-destroy'
 */
export const bulkDestroy = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkDestroy.url(options),
    method: 'post',
})

bulkDestroy.definition = {
    methods: ["post"],
    url: '/admin/catalog/attributes/bulk-destroy',
} satisfies RouteDefinition<["post"]>

/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::bulkDestroy
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:216
 * @route '/admin/catalog/attributes/bulk-destroy'
 */
bulkDestroy.url = (options?: RouteQueryOptions) => {
    return bulkDestroy.definition.url + queryParams(options)
}

/**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::bulkDestroy
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:216
 * @route '/admin/catalog/attributes/bulk-destroy'
 */
bulkDestroy.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkDestroy.url(options),
    method: 'post',
})

    /**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::bulkDestroy
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:216
 * @route '/admin/catalog/attributes/bulk-destroy'
 */
    const bulkDestroyForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: bulkDestroy.url(options),
        method: 'post',
    })

            /**
* @see \Vortex\Product\Http\Controllers\Admin\AttributeController::bulkDestroy
 * @see packages/Product/Http/Controllers/Admin/AttributeController.php:216
 * @route '/admin/catalog/attributes/bulk-destroy'
 */
        bulkDestroyForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: bulkDestroy.url(options),
            method: 'post',
        })
    
    bulkDestroy.form = bulkDestroyForm
const AttributeController = { index, create, store, show, edit, update, destroy, bulkDestroy }

export default AttributeController