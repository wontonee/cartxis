import Http from './Http'
const Product = {
    Http: Object.assign(Http, Http),
}

export default Product