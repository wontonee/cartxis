import Admin from './Admin'
import Product from './Product'
import Shop from './Shop'
import Cart from './Cart'
const Vortex = {
    Admin: Object.assign(Admin, Admin),
Product: Object.assign(Product, Product),
Shop: Object.assign(Shop, Shop),
Cart: Object.assign(Cart, Cart),
}

export default Vortex