import ProductController from './ProductController'
import HomeController from './HomeController'
import CategoryController from './CategoryController'
import SearchController from './SearchController'
const Controllers = {
    ProductController: Object.assign(ProductController, ProductController),
HomeController: Object.assign(HomeController, HomeController),
CategoryController: Object.assign(CategoryController, CategoryController),
SearchController: Object.assign(SearchController, SearchController),
}

export default Controllers