import Http from './Http'
const Shop = {
    Http: Object.assign(Http, Http),
}

export default Shop