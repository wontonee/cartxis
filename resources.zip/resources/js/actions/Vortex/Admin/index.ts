import Http from './Http'
const Admin = {
    Http: Object.assign(Http, Http),
}

export default Admin