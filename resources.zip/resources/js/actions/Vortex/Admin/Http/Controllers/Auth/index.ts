import AdminLoginController from './AdminLoginController'
const Auth = {
    AdminLoginController: Object.assign(AdminLoginController, AdminLoginController),
}

export default Auth